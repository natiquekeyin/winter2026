import Header from './components/Header'
import Events from './components/Events'
import AddEvent from './components/AddEvent'

function App() {
  // TODO:
  // 1. Create state for events
  // 2. Optionally create state for showing/hiding the form
  // 3. Write deleteEvent function
  // 4. Write toggleAttendance function
  // 5. Write addEvent function

  return (
    <div className="container">
      <Header
        title="Event Planner"
        // TODO: pass any props you need
      />

      {/* TODO: conditionally render AddEvent if needed */}
      <AddEvent
        // TODO: pass onAdd prop
      />

      <Events
        // TODO: pass required props
      />
    </div>
  )
}

export default App
