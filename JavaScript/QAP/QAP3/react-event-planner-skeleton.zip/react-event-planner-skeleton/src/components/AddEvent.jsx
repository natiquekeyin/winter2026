import { useState } from 'react'

function AddEvent(props) {
  // TODO:
  // 1. Create state for:
  //    - title
  //    - date
  //    - location
  //    - attending
  // 2. Write onSubmit function
  // 3. Validate title
  // 4. Call onAdd from props
  // 5. Clear the form after submit

  return (
    <form className="add-form">
      <div className="form-control">
        <label>Event Title</label>
        <input
          type="text"
          placeholder="Enter event title"
        />
      </div>

      <div className="form-control">
        <label>Date</label>
        <input
          type="text"
          placeholder="Enter event date"
        />
      </div>

      <div className="form-control">
        <label>Location</label>
        <input
          type="text"
          placeholder="Enter event location"
        />
      </div>

      <div className="form-control form-control-check">
        <label>Attending</label>
        <input
          type="checkbox"
        />
      </div>

      <input type="submit" value="Save Event" className="btn btn-block" />
    </form>
  )
}

export default AddEvent
