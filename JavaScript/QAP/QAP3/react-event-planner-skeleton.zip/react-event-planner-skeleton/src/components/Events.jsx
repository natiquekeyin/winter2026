import Event from './Event'

function Events(props) {
  // TODO:
  // 1. Receive events array from props
  // 2. Receive delete/toggle functions from props
  // 3. Use map() to render Event components

  return (
    <div>
      {/* TODO: render event list here */}
    </div>
  )
}

export default Events
