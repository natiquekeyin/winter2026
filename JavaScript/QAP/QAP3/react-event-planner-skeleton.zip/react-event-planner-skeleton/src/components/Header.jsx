function Header({ title }) {
  return (
    <header className="header">
      <h1>{title}</h1>

      {/* TODO:
          Optional challenge:
          Add a button here to show/hide the form.
      */}
    </header>
  )
}

export default Header
