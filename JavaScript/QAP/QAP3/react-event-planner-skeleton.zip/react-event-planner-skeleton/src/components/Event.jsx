import { FaTimes } from 'react-icons/fa'

function Event(props) {
  // TODO:
  // 1. Receive one event object
  // 2. Receive onDelete function
  // 3. Receive onToggle function
  // 4. Add double-click to toggle attendance
  // 5. Add conditional class when attending is true

  return (
    <div className="event-card">
      <div className="event-top">
        <h3>Event Title Here</h3>
        <FaTimes className="delete-icon" />
      </div>

      <p><strong>Date:</strong> Event Date Here</p>
      <p><strong>Location:</strong> Event Location Here</p>
      <p className="status">Status: Add dynamic status here</p>
    </div>
  )
}

export default Event
