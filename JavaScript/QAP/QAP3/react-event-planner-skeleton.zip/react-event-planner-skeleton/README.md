# React Event Planner Skeleton

This is a **starter skeleton** for the React Event Planner assignment.

## What is included
- Vite + React project setup
- Folder structure
- Empty component files with TODO comments
- Basic CSS styling

## What students must complete
- Create state in `App.jsx`
- Add sample event data
- Pass props between components
- Render events using `map()`
- Delete events
- Toggle attendance on double click
- Build controlled form inputs
- Validate the title field
- Add a new event
- Reset the form after submit

## Suggested starter data
```js
const sampleEvents = [
  {
    id: 1,
    title: 'Web Development Workshop',
    date: 'April 5, 2026 - 10:00 AM',
    location: 'Room 201',
    attending: true,
  },
  {
    id: 2,
    title: 'Career Fair',
    date: 'April 8, 2026 - 1:00 PM',
    location: 'Main Hall',
    attending: false,
  },
  {
    id: 3,
    title: 'Project Presentation',
    date: 'April 12, 2026 - 9:30 AM',
    location: 'Lab 3',
    attending: true,
  },
]
```

## Run instructions
```bash
npm install
npm run dev
```

## File structure
```text
react-event-planner-skeleton/
├── index.html
├── package.json
├── vite.config.js
├── README.md
└── src/
    ├── App.jsx
    ├── main.jsx
    ├── index.css
    └── components/
        ├── Header.jsx
        ├── Events.jsx
        ├── Event.jsx
        └── AddEvent.jsx
```
